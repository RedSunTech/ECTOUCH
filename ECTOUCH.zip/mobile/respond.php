<?php

/**
 * ECTouch Open Source Project
 * ============================================================================
 * Copyright (c) 2012-2014 http://ectouch.cn All rights reserved.
 * ----------------------------------------------------------------------------
 * 文件名称：respond.php
 * ----------------------------------------------------------------------------
 * 功能描述：支付接口通知文件
 * ----------------------------------------------------------------------------
 * Licensed ( http://www.ectouch.cn/docs/license.txt )
 * ----------------------------------------------------------------------------
 */

/* 访问控制 */
define('IN_ECTOUCH', true);

if(!isset($_REQUEST['code']) && !isset($_REQUEST['note1'])){
    header('location: ./?'.$_SERVER['QUERY_STRING']);
    exit;
}

if(!isset($_REQUEST['code'])) {
	$suntech_respond = explode(',', urldecode($_REQUEST['note1']));
	$code = [
		'code' => $suntech_respond[0]
	];
    $code = serialize($code);
    $data = base64_encode($code);
    $data = str_replace(array('+', '/', '='), array('-', '_', ''), $data);
	$_GET['code'] = $data;
}

define('CONTROLLER_NAME', 'Respond');
/* 加载核心文件 */
require ('include/EcTouch.php');
